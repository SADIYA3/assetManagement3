package com.example.assetmanagement3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assetmanagement3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
