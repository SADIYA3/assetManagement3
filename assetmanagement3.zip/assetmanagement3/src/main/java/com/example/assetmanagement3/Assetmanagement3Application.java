package com.example.assetmanagement3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assetmanagement3Application {

	public static void main(String[] args) {
		SpringApplication.run(Assetmanagement3Application.class, args);
	}

}
